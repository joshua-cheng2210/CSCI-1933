Albert Shim - shim0222@umn.edu
Joshua Hor Soong, Cheng - chen7647@umn.edu

Contributions of each partner (if working with a partner)
Joshua
-ArrayList.java
Albert
-LinkedList.java

How to compile and run your program
- you can use these classes to build upon more classes

Any assumptions
- grow() -> to double the size of the ArrayList
- get_last_node() -> to return the last node
- get_index_node() -> to return the node at the index (different from T get(index))


Any known bugs or defects in the program
- 

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Joshua Hor Soong, Cheng
Albert Shim