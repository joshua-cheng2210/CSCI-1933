Group member’s names and x500s
- Albert Shim - shim0222@umn.edu
- Joshua Hor Soong, Cheng - chen7647@umn.edu

Contributions of each partner (if applicable)
Albert Shim - shim0222@umn.edu
- revealmines()
- revealzeroes()
Joshua Hor Soong, Cheng - chen7647@umn.edu
- others

Any assumptions:
- to place a flag:  [x] [y] [-1]
- to dig:           [x] [y] [1]

Additional features that your project had (if applicable)
- getRows()
- getColumns()
- getField()
- getFlag()

Any known bugs or defects in the program

Credit ALL outside references used in completing this project both in the README and within the code that utilizes the referenced material.

Academic Integrity statement

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Joshua Hor Soong, Cheng
Albert Shim